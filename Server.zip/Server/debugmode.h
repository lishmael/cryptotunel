#ifndef DEBUGMODE_H
#define DEBUGMODE_H

// Define DEBUG's to enable some debug output

//#define DEBUG
//#define DEBUG2


#endif // DEBUGMODE_H
